@echo off
chcp 65001 >nul
title Control Bolsas v5 - Instalacion inicial
color 0E
echo.
echo  ============================================================
echo    CONTROL BOLSAS v5 - INSTALACION INICIAL (una sola vez)
echo  ============================================================
echo.

where node >nul 2>nul
if errorlevel 1 (
  color 0C
  echo  [X] No encontre Node.js. Instalalo desde https://nodejs.org (version 20 LTS^)
  echo      y vuelve a ejecutar este archivo.
  pause & exit /b 1
)
for /f "tokens=*" %%v in ('node -v') do echo  [OK] Node.js %%v

where firebase >nul 2>nul
if errorlevel 1 (
  echo  [..] Instalando Firebase CLI de forma global...
  call npm install -g firebase-tools
  if errorlevel 1 ( color 0C & echo  [X] Fallo la instalacion del Firebase CLI. & pause & exit /b 1 )
)
echo  [OK] Firebase CLI listo

if not exist ".env" (
  copy ".env.example" ".env" >nul
  echo.
  echo  [!] Cree el archivo .env a partir de .env.example
  echo      ABRELO AHORA y pega los datos de tu proyecto Firebase.
  notepad .env
)

if not exist ".firebaserc" (
  copy ".firebaserc.example" ".firebaserc" >nul
  echo.
  echo  [!] Cree .firebaserc — escribe ahi el ID de tu proyecto Firebase.
  notepad .firebaserc
)

echo.
echo  [..] Instalando dependencias del frontend...
call npm install
if errorlevel 1 ( color 0C & echo  [X] Fallo npm install. & pause & exit /b 1 )

echo  [..] Instalando dependencias del backend...
call npm --prefix functions install
if errorlevel 1 ( color 0C & echo  [X] Fallo npm install en functions. & pause & exit /b 1 )

echo.
echo  [..] Iniciando sesion en Firebase (se abrira el navegador^)...
call firebase login

echo.
echo  ============================================================
echo    LISTO. Ahora falta configurar el secreto de Gemini:
echo.
echo      firebase functions:secrets:set GOOGLE_GENAI_API_KEY
echo.
echo    Y crear tu usuario administrador (ver README, paso 4^).
echo    Despues ejecuta INSTALL_AND_DEPLOY.bat
echo  ============================================================
pause
