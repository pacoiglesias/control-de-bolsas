@echo off
chcp 65001 >nul
title Control Bolsas v5 - Compilar y desplegar
color 0A
setlocal

echo.
echo  ============================================================
echo    CONTROL BOLSAS v5 - DESPLIEGUE A PRODUCCION
echo  ============================================================
echo.

if not exist ".env" (
  color 0C
  echo  [X] Falta el archivo .env. Ejecuta primero SETUP.bat
  pause & exit /b 1
)
if not exist ".firebaserc" (
  color 0C
  echo  [X] Falta .firebaserc con el ID de tu proyecto. Ejecuta SETUP.bat
  pause & exit /b 1
)

echo  [1/5] Instalando dependencias...
call npm install || goto :fallo
call npm --prefix functions install || goto :fallo

echo.
echo  [2/5] Revisando tipos de TypeScript...
call npm run typecheck || goto :fallo

echo.
echo  [3/5] Compilando el frontend...
call npm run build || goto :fallo

echo.
echo  [4/5] Respaldando en GitHub...
if exist ".git" (
  git add .
  git commit -m "deploy: %DATE% %TIME%"
  git push
  if errorlevel 1 echo  [!] No se pudo hacer push. Continuo con el despliegue.
) else (
  echo  [!] Esta carpeta no es un repositorio git. Me salto el respaldo.
  echo      Usa PUSH_TO_GIT.bat para configurarlo.
)

echo.
echo  [5/5] Desplegando a Firebase (hosting + functions + reglas^)...
call firebase deploy --only hosting,functions,firestore,storage || goto :fallo

echo.
color 0A
echo  ============================================================
echo    DESPLIEGUE COMPLETO
echo    Tu sistema ya esta en linea. La URL aparece arriba,
echo    en la linea "Hosting URL".
echo  ============================================================
pause
exit /b 0

:fallo
color 0C
echo.
echo  ============================================================
echo    ALGO FALLO. Lee el error de arriba.
echo    Errores mas comunes:
echo      - Falta correr: firebase functions:secrets:set GOOGLE_GENAI_API_KEY
echo      - El plan del proyecto no es Blaze (Functions lo exige^)
echo      - Variables VITE_ vacias en .env
echo  ============================================================
pause
exit /b 1
